local M = {}

local im = ui_imgui
local SETTINGS_FILE = "settings/redfox/beambook_standalone.json"
local MAX_MILES = 250000
local METERS_PER_MILE = 1609.34
local MIN_PRICE_MULT = 0.01

local visible = true
local settingsOpen = false
local listings = {}
local generatedAt = 0
local generatedLevel = ""
local lastError = ""

local settings = {
  listingCount = 40,
  feedCount = 24,
  defaultRadiusMiles = 60,
  darkMode = true,
  rememberOpen = false,
  allowQuickTravel = true
}

local listingCountPtr
local feedCountPtr
local radiusPtr
local darkModePtr
local rememberOpenPtr
local quickTravelPtr

local function bbLog(level, message)
  log(level or "I", "[RedFox][BEAMBOOK]", tostring(message))
end

local function ensureSettingsDir()
  if not FS:directoryExists("settings") then FS:directoryCreate("settings") end
  if not FS:directoryExists("settings/redfox") then FS:directoryCreate("settings/redfox") end
end

local function clamp(value, minimum, maximum)
  value = tonumber(value) or minimum
  return math.max(minimum, math.min(maximum, value))
end

local function loadSettings()
  ensureSettingsDir()
  local saved = jsonReadFile(SETTINGS_FILE)
  if type(saved) == "table" then
    for key, value in pairs(saved) do
      if settings[key] ~= nil then settings[key] = value end
    end
  end
  settings.listingCount = clamp(settings.listingCount, 5, 100)
  settings.feedCount = clamp(settings.feedCount, 10, 60)
  settings.defaultRadiusMiles = clamp(settings.defaultRadiusMiles, 5, 500)
  if settings.rememberOpen then visible = saved and saved.visible == true or false end
end

local function saveSettings()
  ensureSettingsDir()
  local payload = deepcopy(settings)
  payload.visible = visible
  jsonWriteFile(SETTINGS_FILE, payload, true)
  bbLog("I", "Settings saved")
end

local function syncPtrsFromSettings()
  if not im then return end
  listingCountPtr = im.IntPtr(settings.listingCount)
  feedCountPtr = im.IntPtr(settings.feedCount)
  radiusPtr = im.IntPtr(settings.defaultRadiusMiles)
  darkModePtr = im.BoolPtr(settings.darkMode)
  rememberOpenPtr = im.BoolPtr(settings.rememberOpen)
  quickTravelPtr = im.BoolPtr(settings.allowQuickTravel)
end

local function currentLevelId()
  if getCurrentLevelIdentifier then return getCurrentLevelIdentifier() or "" end
  return ""
end

local function sendStatus(state, message)
  guihooks.trigger("RedFoxBeamBookStatus", { state = state, message = message })
end

local function wearPriceMult(miles)
  local t = math.min(miles / MAX_MILES, 1)
  return math.max(1 - (t ^ 0.85) * (1 - MIN_PRICE_MULT), MIN_PRICE_MULT)
end

local function roundPrice(value)
  return math.ceil((tonumber(value) or 0) / 100) * 100
end

local function categoryFor(info)
  local text = string.lower(table.concat({
    tostring(info.Type or ""), tostring(info.BodyStyle or ""), tostring(info.Name or ""),
    tostring(info.Configuration or ""), tostring(info.key or "")
  }, " "))
  if string.find(text, "trailer") then return "trailers" end
  if string.find(text, "bus") then return "buses" end
  if string.find(text, "truck") or string.find(text, "pickup") or string.find(text, "semi") then return "trucks" end
  if string.find(text, "van") then return "vans" end
  return "cars"
end

local function displayName(info)
  local brand = info.Brand or info.brand or ""
  local name = info.Name or info.name or info.model or info.key or "Private vehicle"
  local config = info.Configuration or info.configName or ""
  local combined = string.format("%s %s %s", tostring(brand), tostring(name), tostring(config))
  return combined:gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
end

local function getParkingSpot(boundingBox)
  local parkingData = gameplay_parking and gameplay_parking.getParkingSpots()
  local byName = parkingData and parkingData.byName
  if type(byName) ~= "table" then return nil, nil end
  local names = tableKeys(byName)
  if #names == 0 then return nil, nil end

  for _ = 1, 150 do
    local name = names[math.random(#names)]
    local spot = byName[name]
    local tags = spot and spot.customFields and spot.customFields.tags
    local permitted = spot and not (tags and tags.notprivatesale)
    local fits = true
    if permitted and boundingBox and boundingBox[2] and spot.boxFits then
      fits = spot:boxFits(boundingBox[2][1], boundingBox[2][2], boundingBox[2][3])
    end
    if permitted and fits then return name, spot end
  end
  return nil, nil
end

local function sanitizeListing(entry)
  return {
    shopId = entry.shopId,
    title = entry.redfoxTitle,
    price = entry.Value,
    marketValue = entry.marketValue,
    year = entry.year,
    miles = entry.beamBookMiles,
    mileage = entry.Mileage,
    seller = entry.sellerName,
    category = entry.redfoxCategory,
    location = entry.parkingSpotName,
    distanceMeters = entry.distance or 0,
    quickTravelPrice = entry.quickTravelPrice or 0,
    image = entry.preview or entry.previewImage or entry.vehiclePreview,
    map = generatedLevel,
    inspectAvailable = true
  }
end

local function marketplacePayload(ok, errorMessage)
  local clean = {}
  for _, listing in ipairs(listings) do table.insert(clean, sanitizeListing(listing)) end
  return {
    ok = ok,
    error = errorMessage,
    status = ok and "career_connected" or "unavailable",
    map = generatedLevel,
    generatedAt = generatedAt,
    listings = clean,
    settings = settings,
    runtimeLabel = "BUILT — RUNTIME UNTESTED"
  }
end

local function ensureGenerator()
  if not util_configListGenerator then extensions.load("util_configListGenerator") end
  return util_configListGenerator ~= nil
end

local function generateListings(force)
  local level = currentLevelId()
  if not career_career or not career_career.isActive() then
    lastError = "BeamBook vehicle listings require an active Career/RLS session. The social wall remains available."
    listings = {}
    return false, lastError
  end

  if not force and #listings > 0 and generatedLevel == level then return true end
  if not ensureGenerator() then
    lastError = "The stock vehicle configuration generator is unavailable."
    listings = {}
    return false, lastError
  end

  local eligible = util_configListGenerator.getEligibleVehicles()
  if type(eligible) ~= "table" or #eligible == 0 then
    lastError = "No eligible vehicles were returned for this session."
    listings = {}
    return false, lastError
  end

  for _, vehicle in ipairs(eligible) do vehicle.adjustedPopulation = vehicle.Population or 1 end
  local seller = { id = "redfox_beambook", name = "BeamBook", filter = {} }
  local picks = util_configListGenerator.getRandomVehicleInfos(seller, settings.listingCount, eligible, "adjustedPopulation") or {}

  listings = {}
  generatedLevel = level
  generatedAt = os.time()
  local parkingFailures = 0

  for _, info in ipairs(picks) do
    local spotName, spot = getParkingSpot(info.BoundingBox)
    if spot then
      local miles = math.random(0, MAX_MILES)
      local years = info.Years or (info.aggregates and info.aggregates.Years)
      local minYear = years and years.min or 1990
      local maxYear = years and years.max or 2025
      local personality = { name = "Private Seller", priceMultiplier = 1 }
      if career_modules_marketplace and career_modules_marketplace.generatePersonality then
        personality = career_modules_marketplace.generatePersonality(false) or personality
      end

      local entry = deepcopy(info)
      entry.shopId = math.floor(math.random() * 900000000) + 100000000
      entry.sellerId = "private"
      entry.sellerName = personality.name or "Private Seller"
      entry.year = math.random(minYear, maxYear)
      entry.Mileage = math.floor(miles * METERS_PER_MILE)
      entry.beamBookMiles = miles
      entry.marketValue = roundPrice((info.Value or 5000) * wearPriceMult(miles))
      entry.Value = roundPrice(entry.marketValue * (personality.priceMultiplier or 1))
      entry.fees = 0
      entry.parkingSpotName = spotName
      entry.pos = spot.pos
      entry.negotiationPersonality = personality
      entry.negotiationPossible = true
      entry.redfoxTitle = displayName(info)
      entry.redfoxCategory = categoryFor(info)

      if career_modules_quickTravel and entry.pos then
        local qtPrice, distance = career_modules_quickTravel.getPriceForQuickTravel(entry.pos)
        entry.quickTravelPrice = qtPrice or 0
        entry.distance = distance or 0
      end
      table.insert(listings, entry)
    else
      parkingFailures = parkingFailures + 1
    end
  end

  if #listings == 0 then
    lastError = "This map did not provide a usable private-sale parking spot. No vehicle was spawned and no purchase was attempted."
    bbLog("W", lastError)
    return false, lastError
  end

  lastError = ""
  bbLog("I", string.format("Generated %d current-map listings; %d parking failures", #listings, parkingFailures))
  return true
end

local function findListing(shopId)
  shopId = tonumber(shopId)
  for _, listing in ipairs(listings) do
    if tonumber(listing.shopId) == shopId then return listing end
  end
end

local function stageListingForStockFlow(listing)
  if not career_modules_vehicleShopping or not career_modules_vehicleShopping.getVehiclesInShop then return end
  local shop = career_modules_vehicleShopping.getVehiclesInShop()
  if type(shop) ~= "table" then return end
  for index = #shop, 1, -1 do
    if shop[index].redfoxBeamBookStandalone then table.remove(shop, index) end
  end
  listing.redfoxBeamBookStandalone = true
  table.insert(shop, listing)
end

function M.getMarketplaceDataJson()
  local ok, err = generateListings(false)
  return jsonEncode(marketplacePayload(ok, err))
end

function M.refreshMarketplaceDataJson()
  local ok, err = generateListings(true)
  return jsonEncode(marketplacePayload(ok, err))
end

function M.inspectListingJson(shopId, teleport)
  if not career_career or not career_career.isActive() then
    return jsonEncode({ ok = false, error = "An active Career/RLS session is required." })
  end
  local listing = findListing(shopId)
  if not listing then return jsonEncode({ ok = false, error = "That listing is no longer available. Refresh Marketplace." }) end

  if not career_modules_inspectVehicle then extensions.load("career_modules_inspectVehicle") end
  if not career_modules_inspectVehicle or not career_modules_inspectVehicle.startInspection then
    return jsonEncode({ ok = false, error = "The stock private-seller inspection service is unavailable." })
  end

  local live = deepcopy(listing)
  live.sellerId = "private"
  stageListingForStockFlow(live)
  bbLog("I", string.format("Opening stock private-seller inspection for shopId=%s", tostring(shopId)))
  local ok, result = pcall(career_modules_inspectVehicle.startInspection, live, teleport == true and settings.allowQuickTravel)
  if not ok then
    bbLog("E", "Inspection failed: " .. tostring(result))
    return jsonEncode({ ok = false, error = "Stock inspection failed. Check beamng.log for [RedFox][BEAMBOOK]." })
  end
  visible = false
  guihooks.trigger("RedFoxBeamBookVisibility", { visible = false })
  return jsonEncode({ ok = true, status = "inspection_requested", ownershipUnproven = true })
end

function M.setVisible(value)
  visible = value == true
  if settings.rememberOpen then saveSettings() end
end

function M.toggleVisible()
  visible = not visible
  guihooks.trigger("RedFoxBeamBookVisibility", { visible = visible })
  if settings.rememberOpen then saveSettings() end
  bbLog("I", "Visibility toggled to " .. tostring(visible))
end

function M.openWindow() visible = true; guihooks.trigger("RedFoxBeamBookVisibility", { visible = true }) end
function M.closeWindow() visible = false; guihooks.trigger("RedFoxBeamBookVisibility", { visible = false }) end
function M.isWindowOpen() return visible end
function M.setHubControlled(_) end

function M.openSettings()
  settingsOpen = true
  bbLog("I", "WEUI settings requested; open World Editor if the window is not visible")
end

function M.onEditorGui()
  if not settingsOpen or not im then return end
  if not listingCountPtr then syncPtrsFromSettings() end

  local openPtr = im.BoolPtr(settingsOpen)
  im.SetNextWindowSize(im.ImVec2(520, 430), im.Cond_FirstUseEver)
  if im.Begin("RedFox BeamBook Settings (JOB-05)", openPtr) then
    im.TextWrapped("Standalone test settings. Marketplace generation runs only when BeamBook requests listings; it never runs at map load.")
    im.Separator()
    im.InputInt("Vehicle listings", listingCountPtr)
    im.InputInt("Initial feed posts", feedCountPtr)
    im.InputInt("Default distance (miles)", radiusPtr)
    im.Checkbox("Dark mode", darkModePtr)
    im.Checkbox("Remember open state", rememberOpenPtr)
    im.Checkbox("Allow quick travel button", quickTravelPtr)
    im.Separator()
    im.TextWrapped("Status: BUILT — RUNTIME UNTESTED")
    im.TextWrapped("Current map: " .. tostring(generatedLevel ~= "" and generatedLevel or currentLevelId()))
    im.TextWrapped("Generated vehicle listings: " .. tostring(#listings))
    if lastError ~= "" then im.TextWrapped("Last error: " .. lastError) end

    if im.Button("Save settings") then
      settings.listingCount = clamp(listingCountPtr[0], 5, 100)
      settings.feedCount = clamp(feedCountPtr[0], 10, 60)
      settings.defaultRadiusMiles = clamp(radiusPtr[0], 5, 500)
      settings.darkMode = darkModePtr[0]
      settings.rememberOpen = rememberOpenPtr[0]
      settings.allowQuickTravel = quickTravelPtr[0]
      saveSettings()
      guihooks.trigger("RedFoxBeamBookSettings", deepcopy(settings))
    end
    im.SameLine()
    if im.Button("Regenerate Marketplace") then
      local ok, err = generateListings(true)
      sendStatus(ok and "ready" or "error", err or "Listings regenerated")
    end
  end
  im.End()
  settingsOpen = openPtr[0]
end

function M.onExtensionLoaded()
  loadSettings()
  syncPtrsFromSettings()
  bbLog("I", "Standalone extension loaded without generating listings or patching Career startup")
end

return M
