REDFOX BEAMBOOK LOGGING AND TESTING README
STATUS: BUILT — RUNTIME UNTESTED

PRIMARY PREFIX

  [RedFox][BEAMBOOK]

EXPECTED LOG EVENTS

- Standalone extension loaded without generating listings or patching
  Career startup.
- Visibility toggled.
- Settings saved.
- Current-map listing count and parking failure count.
- Stock private-seller inspection requested with shopId.
- Explicit error if Career, generator, inspection or parking is unavailable.

THERE IS NO SUCCESS LOG FOR PURCHASE COMPLETION

JOB-05 does not own money, ownership, inventory, garage, or storage. A call
to stock inspection is only an inspection request. Captain David must verify
the normal game/RLS transaction result.

MAP MATRIX

  A. West Coast USA
  B. One non-West-Coast map with parking spots

VIEWPORT MATRIX (STATIC PASS)

  PC:    1440 x 1000
  Phone: 390 x 844

RUNTIME CHECKPOINTS

  UIAPP_DISCOVERY
  INPUT_ACTION_DISCOVERY
  KEY_OPEN_CLOSE
  WEUI_SETTINGS
  WALL_LOAD
  FEED_RANDOM_SUBSET
  LOAD_MORE
  MARKET_FILTERS
  CAREER_LISTINGS
  CURRENT_MAP_PARKING
  SHOW_ON_MAP
  QUICK_TRAVEL
  STOCK_INSPECTION
  STOCK_PURCHASE
  REAL_MONEY_RESULT
  REAL_OWNERSHIP_RESULT
  REAL_STORAGE_RESULT

FAILURE REPORT FORMAT

  Checkpoint:
  Map:
  Exact action:
  Visible result:
  Expected result:
  beamng.log excerpt:
  Was original beamBook.zip disabled? yes/no
  Was this the only JOB-05 ZIP installed? yes/no

TRUTH LABELS

  BUILT — RUNTIME UNTESTED
  PARTIAL
  BLOCKED
  FAILED — STOPPED
  DAVID-TESTED WORKING

"Should work" is not evidence.
