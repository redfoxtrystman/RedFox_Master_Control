angular.module('beamng.apps').directive('redfoxBeamBook', ['$rootScope', function ($rootScope) {
  return {
    templateUrl: '/ui/modules/apps/RedFoxBeamBook/app.html',
    replace: true,
    restrict: 'EA',
    link: function (scope, element) {
      var frame = element[0].querySelector('.redfox-beambook-frame')
      scope.beamBookVisible = true

      function lua(command, callback) {
        if (window.bngApi && bngApi.engineLua) bngApi.engineLua(command, callback)
      }

      function post(type, payload) {
        if (frame && frame.contentWindow) frame.contentWindow.postMessage({ type: type, payload: payload }, '*')
      }

      function parseResult(raw) {
        if (typeof raw === 'object') return raw
        try { return JSON.parse(raw) } catch (err) { return { ok: false, error: 'BeamBook bridge returned invalid JSON.' } }
      }

      lua("extensions.load('redfox_beamBookStandalone')")

      scope.closeBeamBook = function () {
        scope.beamBookVisible = false
        lua("extensions.redfox_beamBookStandalone.setVisible(false)")
      }

      scope.openBeamBookSettings = function () {
        lua("extensions.redfox_beamBookStandalone.openSettings()")
      }

      var unhook = $rootScope.$on('RedFoxBeamBookVisibility', function (_, data) {
        scope.$evalAsync(function () {
          scope.beamBookVisible = !data || data.visible !== false
          if (scope.beamBookVisible) post('bb-visible', { visible: true })
        })
      })

      function onMessage(event) {
        var msg = event.data || {}
        if (!msg.type || msg.type.indexOf('bb-') !== 0) return

        if (msg.type === 'bb-ready' || msg.type === 'bb-request-listings') {
          lua("extensions.redfox_beamBookStandalone.getMarketplaceDataJson()", function (raw) {
            post('bb-marketplace-data', parseResult(raw))
          })
        } else if (msg.type === 'bb-refresh-listings') {
          lua("extensions.redfox_beamBookStandalone.refreshMarketplaceDataJson()", function (raw) {
            post('bb-marketplace-data', parseResult(raw))
          })
        } else if (msg.type === 'bb-inspect-listing') {
          var id = Number(msg.payload && msg.payload.shopId)
          var teleport = !!(msg.payload && msg.payload.teleport)
          if (!isFinite(id)) return post('bb-action-result', { ok: false, error: 'Invalid listing id.' })
          lua("extensions.redfox_beamBookStandalone.inspectListingJson(" + id + ", " + (teleport ? 'true' : 'false') + ")", function (raw) {
            post('bb-action-result', parseResult(raw))
          })
        } else if (msg.type === 'bb-open-settings') {
          scope.$evalAsync(scope.openBeamBookSettings)
        } else if (msg.type === 'bb-close') {
          scope.$evalAsync(scope.closeBeamBook)
        }
      }

      window.addEventListener('message', onMessage)
      scope.$on('$destroy', function () {
        unhook()
        window.removeEventListener('message', onMessage)
      })
    }
  }
}])
