(function () {
  'use strict'

  const $ = (selector, root = document) => root.querySelector(selector)
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector))
  const state = {
    sourcePosts: [],
    sessionPosts: [],
    visiblePosts: [],
    profiles: [],
    feedLimit: 16,
    feedFilter: 'all',
    activeView: 'wall',
    marketplace: [],
    activeCategory: 'all',
    selectedListing: null,
    careerConnected: false,
    settings: { defaultRadiusMiles: 60, darkMode: true, allowQuickTravel: true }
  }

  const firstNames = ['Bubba', 'Darla', 'Kip', 'Maya', 'Hank', 'Nova', 'Ray', 'Lena', 'Terry', 'Skeeter', 'Peggy', 'Zed', 'Sam', 'Briggs', 'Roxy', 'Dale', 'Frankie', 'Linda', 'Billy', 'Marlene', 'Otis', 'Cletus', 'Jolene', 'Tucker', 'Dusty', 'Nadine', 'Wade', 'Tammy', 'Gus', 'Vera', 'Rusty', 'Mavis', 'Cliff', 'Dottie', 'Leon', 'Penny']
  const lastNames = ['Lugnut', 'Flatbed', 'No-Insurance', 'Axle', 'Torque', 'Diesel', 'Wrench', 'Clutch', 'Gravel', 'Rustwell', 'Towman', 'Backfire', 'Oversteer', 'Crankcase', 'Muffler', 'Pothole', 'Gearbox', 'Redline', 'Junkman', 'Camber', 'Two-Stroke', 'Brakecheck', 'Roadsalt', 'Mudflap', 'Ratchet', 'Headgasket', 'Piston', 'Skidmark', 'Tailgate', 'Hubcap', 'Winch', 'Oilpan']
  const colors = [
    ['#de684d', '#5a211d'], ['#4b9bd6', '#18334f'], ['#8e66d3', '#302048'], ['#d5a73b', '#554018'],
    ['#43a77a', '#173d31'], ['#c65984', '#4d1e31'], ['#789449', '#28351c'], ['#d07843', '#512b19']
  ]
  const vehicleColors = ['#d8d3c8', '#a33b42', '#4a7192', '#d2a54d', '#597154', '#6c5d85', '#b8b9ba', '#884c32']
  const sessionSeed = Number(sessionStorage.getItem('beambook_seed')) || (Date.now() % 2147483647)
  sessionStorage.setItem('beambook_seed', String(sessionSeed))

  function seeded(index) {
    let x = Math.sin((sessionSeed + index * 7919) * 12.9898) * 43758.5453
    return x - Math.floor(x)
  }

  function hash(text) {
    let value = 2166136261
    String(text).split('').forEach(char => { value ^= char.charCodeAt(0); value = Math.imul(value, 16777619) })
    return Math.abs(value >>> 0)
  }

  function shuffle(list) {
    const copy = list.slice()
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(seeded(i + copy.length) * (i + 1))
      ;[copy[i], copy[j]] = [copy[j], copy[i]]
    }
    return copy
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>'"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]))
  }

  function money(value) {
    const number = Number(value || 0)
    return number === 0 ? 'FREE' : '$' + Math.round(number).toLocaleString()
  }

  function miles(meters) {
    return Math.max(0, Number(meters || 0) / 1609.34)
  }

  function toast(message) {
    const node = $('#toast')
    node.textContent = message
    node.classList.add('show')
    clearTimeout(toast.timer)
    toast.timer = setTimeout(() => node.classList.remove('show'), 2700)
  }

  function postToHost(type, payload) {
    if (window.parent && window.parent !== window) window.parent.postMessage({ type, payload }, '*')
  }

  function makeProfiles() {
    const profiles = []
    firstNames.forEach((first, firstIndex) => {
      lastNames.forEach((last, lastIndex) => {
        if (profiles.length >= 240) return
        const name = first + ' ' + last
        const color = colors[(firstIndex * 3 + lastIndex) % colors.length]
        profiles.push({ name, initials: first[0] + last[0], color, contributor: (firstIndex + lastIndex) % 7 === 0 ? 'All-star contributor' : (firstIndex + lastIndex) % 4 === 0 ? 'Rising contributor' : '' })
      })
    })
    state.profiles = profiles
  }

  function profileFor(name) {
    const match = state.profiles.find(profile => profile.name === name)
    if (match) return match
    const key = hash(name)
    const color = colors[key % colors.length]
    const words = String(name || 'Private Driver').trim().split(/\s+/)
    return { name: name || 'Private Driver', initials: (words[0][0] || 'P') + (words[1] ? words[1][0] : ''), color, contributor: key % 9 === 0 ? 'All-star contributor' : key % 5 === 0 ? 'Rising contributor' : '' }
  }

  function avatar(profile, extra = '') {
    return `<span class="avatar ${extra}" style="--avatar:linear-gradient(145deg,${profile.color[0]},${profile.color[1]})">${escapeHtml(profile.initials)}</span>`
  }

  function relativeTime(index) {
    const choices = ['14m', '32m', '1h', '2h', '4h', '7h', '15h', '1d', '2d', 'June 28 at 8:42 PM']
    return choices[Math.floor(seeded(index + 55) * choices.length)]
  }

  function sceneKind(post, index) {
    const text = [post.category, post.title, post.body, ...(post.tags || [])].join(' ').toLowerCase()
    if (text.includes('crash') || text.includes('accident') || text.includes('wreck')) return 'forest crashed'
    if (text.includes('utah') || text.includes('desert') || text.includes('johnson')) return 'desert'
    if (text.includes('night') || text.includes('police')) return 'night'
    if (text.includes('belasco') || text.includes('traffic') || text.includes('road')) return 'city'
    return index % 3 === 0 ? 'desert' : index % 3 === 1 ? 'forest' : 'city'
  }

  function sceneHtml(post, index, galleryIndex = 0) {
    const type = sceneKind(post, index + galleryIndex)
    const truck = /truck|diesel|flatbed|tow|trailer|bus/i.test([post.title, post.body, ...(post.tags || [])].join(' '))
    const crashed = type.includes('crashed')
    const color = vehicleColors[(hash(post.id) + galleryIndex) % vehicleColors.length]
    const caption = galleryIndex ? `View ${galleryIndex + 1}` : (post.location || post.category || 'BeamBook photo')
    return `<div class="scene ${type}" data-caption="${escapeHtml(caption)}"><span class="vehicle ${truck ? 'truck' : ''} ${crashed ? 'crashed' : ''}" style="--vehicle:${color}"></span>${crashed ? '<span class="smoke"></span>' : ''}</div>`
  }

  function mediaHtml(post, index) {
    const hasMedia = post.category === 'Marketplace' || post.category === 'Accident Report' || post.category === 'Garage Talk' || post.category === 'Road Closure' || index % 3 !== 1
    if (!hasMedia) return ''
    const gallery = post.category === 'Accident Report' || index % 7 === 0
    if (gallery) return `<div class="post-media gallery">${sceneHtml(post, index, 0)}${sceneHtml(post, index, 1)}${sceneHtml(post, index, 2)}</div>`
    return `<div class="post-media single">${sceneHtml(post, index, 0)}</div>`
  }

  function badgeHtml(profile, isAuthor) {
    const pieces = []
    if (isAuthor) pieces.push('<span class="badge author">Author</span>')
    if (profile.contributor) pieces.push(`<span class="badge ${profile.contributor.startsWith('All') ? 'allstar' : 'rising'}">${escapeHtml(profile.contributor)}</span>`)
    return pieces.join('')
  }

  function commentHtml(comment, post, index, reply) {
    const author = comment.author || state.profiles[(hash(post.id) + index * 17) % state.profiles.length].name
    const profile = profileFor(author)
    const isAuthor = author === post.author
    let body = comment.body || 'Following this because I have questions and none of them are responsible.'
    if (reply && index % 2 === 0) body = `<span class="mention">${escapeHtml(post.author)}</span> ` + escapeHtml(body)
    else body = escapeHtml(body)
    return `<div class="comment ${reply ? 'reply' : ''}">${avatar(profile)}<div class="comment-body"><div class="comment-bubble"><b>${escapeHtml(author)}</b>${badgeHtml(profile, isAuthor)}<br>${body}</div><div class="comment-tools"><span>Like</span><span>Reply</span><span>${relativeTime(index + 80)}</span></div></div></div>`
  }

  function renderComments(post, index) {
    const supplied = Array.isArray(post.comments) ? post.comments.slice(0, 5) : []
    while (supplied.length < 4) {
      const profile = state.profiles[(hash(post.id) + supplied.length * 29) % state.profiles.length]
      const extras = ['Marketplace people will call that “minor cosmetic wear.”', 'Is it still available or did it drive away by itself?', 'Check the frame before you check the comments.', 'I know a guy with a trailer and extremely low standards.', 'The insurance adjuster just closed the app.']
      supplied.push({ author: profile.name, body: extras[(index + supplied.length) % extras.length] })
    }
    return `<div class="comment-sort">Most relevant⌄</div><div class="comment-composer">${avatar(profileFor('RedFox Driver'), 'self')}<button>Comment as RedFox Driver</button></div><div class="comments">${supplied.slice(0, 2).map((comment, i) => commentHtml(comment, post, i, i === 1)).join('')}<div class="comments-collapsed">${supplied.slice(2).map((comment, i) => commentHtml(comment, post, i + 2, i % 2 === 0)).join('')}</div></div>`
  }

  function renderPost(post, index) {
    const profile = profileFor(post.author)
    const likes = 8 + (hash(post.id) % 490)
    const commentCount = Math.max((post.comments || []).length, 3) + (hash(post.id + 'comments') % 72)
    const shares = hash(post.id + 'shares') % 19
    const allStar = badgeHtml(profile, false)
    return `<article class="post" data-post-id="${escapeHtml(post.id)}"><header class="post-head">${avatar(profile)}<div class="identity"><span class="group-name">BeamNG.drive Community</span><span class="byline"><span class="author">${escapeHtml(post.author)}</span> · ${allStar} · ${relativeTime(index)} · ◉</span></div><button class="post-menu">•••</button></header><div class="post-copy"><h2>${escapeHtml(post.title || '')}</h2><p>${escapeHtml(post.body || '')}</p>${post.location ? `<span class="post-location">${escapeHtml(post.location)}</span>` : ''}</div>${mediaHtml(post, index)}<div class="post-stats"><span class="reactions"><i class="reaction">●</i><i class="reaction laugh">☺</i><i class="reaction heart">♥</i>&nbsp;${likes}</span><span>${commentCount} comments · ${shares} shares</span></div><div class="post-actions"><button data-like>♡ Like</button><button data-comments>◯ Comment</button><button data-share>↗ Share</button></div>${renderComments(post, index)}</article>`
  }

  function filteredFeed() {
    if (state.feedFilter === 'all') return state.sessionPosts
    return state.sessionPosts.filter(post => post.category === state.feedFilter)
  }

  function renderFeed() {
    const posts = filteredFeed()
    state.visiblePosts = posts.slice(0, state.feedLimit)
    $('#feedList').innerHTML = state.visiblePosts.map(renderPost).join('') || '<div class="placeholder card"><h2>No posts in this filter</h2><p>Try another category. The full source pack is still loaded.</p></div>'
    $('#feedSummary').textContent = `${state.visiblePosts.length} shown from ${posts.length} session picks · ${state.sourcePosts.length} total source posts · ${state.profiles.length} profile identities`
    $('#loadMore').hidden = state.visiblePosts.length >= posts.length
    bindPostActions()
  }

  function bindPostActions() {
    $$('[data-like]').forEach(button => button.addEventListener('click', () => {
      button.classList.toggle('liked')
      button.textContent = button.classList.contains('liked') ? '● Liked' : '♡ Like'
    }))
    $$('[data-comments]').forEach(button => button.addEventListener('click', () => button.closest('.post').classList.toggle('show-comments')))
    $$('[data-share]').forEach(button => button.addEventListener('click', () => toast('Post link copied inside this BeamBook session.')))
  }

  function staticMarketplaceItems() {
    return state.sourcePosts.filter(post => post.category === 'Marketplace').slice(0, 90).map((post, index) => {
      const tags = (post.tags || []).join(' ').toLowerCase()
      let category = post.itemType === 'prop' ? 'props' : /truck|diesel|semi|pickup/.test(tags + post.title.toLowerCase()) ? 'trucks' : /bus/.test(tags + post.title.toLowerCase()) ? 'buses' : /trailer/.test(tags + post.title.toLowerCase()) ? 'trailers' : post.itemType === 'vehicle' ? 'cars' : 'other'
      return {
        id: 'catalog-' + post.id,
        shopId: null,
        title: post.title,
        price: Number(post.price || 0),
        seller: post.author,
        category,
        location: post.location || 'Current map area',
        distanceMeters: (5 + seeded(index + 400) * 90) * 1609.34,
        miles: 0,
        year: '',
        inspectAvailable: false,
        source: 'catalog',
        buyable: post.buyable === true && post.purchaseEnabled === true,
        badge: post.uiBadge || 'Post only',
        body: post.body
      }
    })
  }

  function normalizedEngineListing(item, index) {
    return Object.assign({ id: 'career-' + item.shopId, source: 'career', inspectAvailable: true, buyable: true, badge: 'Inspect on map' }, item, { color: vehicleColors[index % vehicleColors.length] })
  }

  function filteredMarketplace() {
    const query = $('#marketSearch').value.trim().toLowerCase()
    const minimum = Number($('#minPrice').value || 0)
    const maximum = Number($('#maxPrice').value || Infinity)
    const radius = Number($('#distanceFilter').value || 500)
    let list = state.marketplace.filter(item => {
      const category = state.activeCategory === 'all' || item.category === state.activeCategory
      const text = [item.title, item.seller, item.location, item.category].join(' ').toLowerCase()
      const withinPrice = Number(item.price || 0) >= minimum && Number(item.price || 0) <= maximum
      const withinDistance = !item.inspectAvailable || miles(item.distanceMeters) <= radius
      return category && withinPrice && withinDistance && (!query || text.includes(query))
    })
    const sort = $('#marketSort').value
    if (sort === 'priceAsc') list.sort((a, b) => a.price - b.price)
    if (sort === 'priceDesc') list.sort((a, b) => b.price - a.price)
    if (sort === 'distance') list.sort((a, b) => a.distanceMeters - b.distanceMeters)
    if (sort === 'mileage') list.sort((a, b) => a.miles - b.miles)
    return list
  }

  function listingCard(item, index) {
    const color = item.color || vehicleColors[hash(item.id) % vehicleColors.length]
    const location = item.inspectAvailable ? `${miles(item.distanceMeters).toFixed(1)} mi · ${item.location || 'current map'}` : `${item.location || 'BeamBook catalog'} · ${item.badge || 'Post only'}`
    return `<article class="listing-card"><button data-listing-id="${escapeHtml(item.id)}"><div class="listing-art"><span class="listing-tag">${escapeHtml(item.category)}</span><span class="mini-car" style="--vehicle:${color}"></span></div><div class="listing-copy"><strong>${money(item.price)}</strong><b>${escapeHtml(item.title)}</b><span>${escapeHtml(location)}</span></div></button></article>`
  }

  function renderMarketplace() {
    const list = filteredMarketplace()
    $('#marketGrid').innerHTML = list.map(listingCard).join('') || '<div class="placeholder card"><h2>No listings match</h2><p>Change the category, price or distance filters.</p></div>'
    $('#marketCount').textContent = `${list.length} listings`
    $('#marketSubhead').textContent = state.careerConnected ? 'Career/RLS vehicles plus BeamBook catalog posts' : 'BeamBook catalog posts; Career vehicles unavailable'
    $$('[data-listing-id]').forEach(button => button.addEventListener('click', () => openListing(button.dataset.listingId)))
  }

  function openListing(id) {
    const item = state.marketplace.find(listing => String(listing.id) === String(id))
    if (!item) return
    state.selectedListing = item
    $('#listingTitle').textContent = item.title
    $('#listingPrice').textContent = money(item.price)
    $('#listingMeta').textContent = item.inspectAvailable ? `Posted recently · ${miles(item.distanceMeters).toFixed(1)} miles away · ${item.map || 'current map'}` : `${item.location || 'BeamBook catalog'} · ${item.badge || 'Post only'}`
    $('#listingSeller').textContent = item.seller || 'Private Seller'
    const profile = profileFor(item.seller || 'Private Seller')
    $('#sellerAvatar').textContent = profile.initials
    $('#sellerAvatar').style.setProperty('--avatar', `linear-gradient(145deg,${profile.color[0]},${profile.color[1]})`)
    const color = item.color || vehicleColors[hash(item.id) % vehicleColors.length]
    $('#listingMainArt .listing-car').style.setProperty('--vehicle', color)
    $('#listingThumbs').innerHTML = [0, 1, 2, 3, 4].map((_, index) => `<button class="thumb ${index === 0 ? 'active' : ''}" style="--thumb:${vehicleColors[(hash(item.id) + index) % vehicleColors.length]}"></button>`).join('')
    $('#listingFacts').innerHTML = item.inspectAvailable
      ? `<div class="fact"><i>⌁</i><div><small>Mileage</small><b>${Math.round(Number(item.miles || 0)).toLocaleString()} miles</b></div></div><div class="fact"><i>▣</i><div><small>Model year</small><b>${escapeHtml(item.year || 'Unknown')}</b></div></div><div class="fact"><i>⌖</i><div><small>Inspection location</small><b>${escapeHtml(item.location || 'Current-map parking spot')}</b></div></div>`
      : `<div class="fact"><i>◆</i><div><small>BeamBook catalog post</small><b>${escapeHtml(item.body || 'No game item mapping is connected.')}</b></div></div>`
    $('#inspectButton').hidden = !item.inspectAvailable
    $('#quickTravelButton').hidden = !item.inspectAvailable || !state.settings.allowQuickTravel
    $('#actionStatus').textContent = item.inspectAvailable ? 'Runtime purchase completion is unproven until Captain David tests it.' : 'No purchase action is exposed. Props and catalog posts never fake a transaction.'
    $('#listingModal').classList.add('show')
    $('#listingModal').setAttribute('aria-hidden', 'false')
  }

  function requestInspection(teleport) {
    const item = state.selectedListing
    if (!item || !item.inspectAvailable || !item.shopId) return
    $('#actionStatus').textContent = teleport ? 'Requesting stock quick-travel inspection…' : 'Requesting stock current-map inspection…'
    postToHost('bb-inspect-listing', { shopId: item.shopId, teleport })
  }

  function updateMarketConnection(payload) {
    const engine = payload && Array.isArray(payload.listings) ? payload.listings.map(normalizedEngineListing) : []
    state.careerConnected = !!(payload && payload.ok)
    if (payload && payload.settings) {
      state.settings = Object.assign(state.settings, payload.settings)
      $('#distanceFilter').value = state.settings.defaultRadiusMiles || 60
      $('#distanceOutput').textContent = `${$('#distanceFilter').value} mi`
      setTheme(state.settings.darkMode === false ? 'light' : 'dark', false)
    }
    state.marketplace = engine.concat(staticMarketplaceItems())
    const notice = $('#marketNotice')
    notice.dataset.state = state.careerConnected ? 'ready' : 'error'
    notice.innerHTML = state.careerConnected
      ? `<b>${engine.length} current-map private-seller vehicles loaded</b><span>Opening a vehicle delegates to the stock inspection path. Ownership/storage remain game/RLS responsibilities.</span>`
      : `<b>Career vehicle listings unavailable</b><span>${escapeHtml((payload && payload.error) || 'Open BeamBook inside an active Career/RLS session. The wall and non-purchasing catalog remain available.')}</span>`
    $('#connectionStatus').dataset.state = state.careerConnected ? 'ready' : 'offline'
    $('#connectionStatus').textContent = state.careerConnected ? 'Career connected' : 'Wall only'
    renderMarketplace()
  }

  function setView(view) {
    state.activeView = view
    document.body.classList.toggle('market-mode', view === 'market')
    $$('.view').forEach(node => node.classList.remove('active'))
    $$('.main-tabs button').forEach(button => button.classList.toggle('active', button.dataset.view === view))
    if (view === 'wall') $('#view-wall').classList.add('active')
    else if (view === 'market') { $('#view-market').classList.add('active'); renderMarketplace(); postToHost('bb-request-listings') }
    else {
      $('#view-placeholder').classList.add('active')
      const descriptions = {
        groups: 'Group discovery is represented in the wall layout for this standalone test. Shared IceFox navigation comes later.',
        friends: 'The profile pool contains 240 possible BeamBook identities. A server-backed friend graph is not part of JOB-05.',
        saved: 'Saved-listing persistence will bind to the shared platform contract later. This test does not invent shared storage.',
        watch: 'Video posts use the same wall cards. Playback is outside this first isolated test.',
        logs: 'Search beamng.log for [RedFox][BEAMBOOK]. Runtime status remains unproven until Captain David tests this ZIP.',
        profile: 'RedFox Driver is the local test identity. No online account is created.'
      }
      $('#placeholderTitle').textContent = view[0].toUpperCase() + view.slice(1)
      $('#placeholderText').textContent = descriptions[view] || 'This section is outside the first JOB-05 standalone test.'
    }
    window.scrollTo(0, 0)
  }

  function setTheme(theme, notify = true) {
    document.documentElement.dataset.theme = theme
    $('#themeButton').textContent = theme === 'dark' ? '☾' : '☀'
    localStorage.setItem('beambook_theme', theme)
    if (notify) toast(`${theme === 'dark' ? 'Dark' : 'Light'} BeamBook theme enabled`)
  }

  function bindUi() {
    $$('[data-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.view)))
    $('#marketMark').addEventListener('click', () => setView('market'))
    $('#settingsButton').addEventListener('click', () => postToHost('bb-open-settings'))
    $('#marketSettings').addEventListener('click', () => postToHost('bb-open-settings'))
    $('#themeButton').addEventListener('click', () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'))
    $('#composerPrompt').addEventListener('click', () => $('#postModal').classList.add('show'))
    $('#publishPost').addEventListener('click', () => {
      const body = $('#newPostText').value.trim()
      if (!body) return toast('Write something first.')
      state.sessionPosts.unshift({ id: 'local-' + Date.now(), author: 'RedFox Driver', category: 'Community', title: 'RedFox Driver posted', body, location: 'Current session', tags: ['local'], comments: [] })
      $('#newPostText').value = ''
      closeModals(); renderFeed(); toast('Added to this BeamBook session')
    })
    $$('[data-close-modal]').forEach(button => button.addEventListener('click', closeModals))
    $$('.modal-layer').forEach(layer => layer.addEventListener('click', event => { if (event.target === layer) closeModals() }))
    $('#loadMore').addEventListener('click', () => { state.feedLimit += 10; renderFeed() })
    $('#feedFilter').addEventListener('change', event => { state.feedFilter = event.target.value; state.feedLimit = 16; renderFeed() })
    $$('[data-feed-filter]').forEach(button => button.addEventListener('click', () => { state.feedFilter = button.dataset.feedFilter; $('#feedFilter').value = state.feedFilter; setView('wall'); renderFeed() }))
    $$('[data-market-category]').forEach(button => button.addEventListener('click', () => {
      state.activeCategory = button.dataset.marketCategory
      $$('[data-market-category]').forEach(node => node.classList.toggle('active', node === button))
      renderMarketplace()
    }))
    ;['marketSearch', 'minPrice', 'maxPrice', 'marketSort'].forEach(id => $('#' + id).addEventListener('input', renderMarketplace))
    $('#distanceFilter').addEventListener('input', event => { $('#distanceOutput').textContent = `${event.target.value} mi`; renderMarketplace() })
    $('#refreshMarket').addEventListener('click', () => { $('#marketNotice').innerHTML = '<b>Refreshing current-map listings…</b><span>No startup or map-load generation is used.</span>'; postToHost('bb-refresh-listings') })
    $('#inspectButton').addEventListener('click', () => requestInspection(false))
    $('#quickTravelButton').addEventListener('click', () => requestInspection(true))
    $('#globalSearch').addEventListener('input', event => {
      if (state.activeView === 'market') { $('#marketSearch').value = event.target.value; renderMarketplace() }
      else {
        const query = event.target.value.trim().toLowerCase()
        if (!query) state.sessionPosts = shuffle(state.sourcePosts).slice(0, 100)
        else state.sessionPosts = state.sourcePosts.filter(post => [post.author, post.title, post.body, post.location, post.category].join(' ').toLowerCase().includes(query)).slice(0, 100)
        state.feedLimit = 16; renderFeed()
      }
    })
  }

  function closeModals() {
    $$('.modal-layer').forEach(layer => { layer.classList.remove('show'); layer.setAttribute('aria-hidden', 'true') })
  }

  function onHostMessage(event) {
    const message = event.data || {}
    if (message.type === 'bb-marketplace-data') updateMarketConnection(message.payload || {})
    if (message.type === 'bb-action-result') {
      const result = message.payload || {}
      $('#actionStatus').textContent = result.ok ? 'Stock inspection was requested. Runtime ownership and storage are still unproven.' : (result.error || 'Inspection request failed.')
      if (result.ok) { toast('Inspection requested through the game flow'); setTimeout(closeModals, 800) }
    }
    if (message.type === 'bb-visible') postToHost('bb-request-listings')
    if (message.type === 'bb-settings') updateMarketConnection({ ok: state.careerConnected, listings: state.marketplace.filter(item => item.source === 'career'), settings: message.payload })
  }

  async function loadContent() {
    try {
      const response = await fetch('assets/data/beambook_posts.json')
      if (!response.ok) throw new Error('HTTP ' + response.status)
      const data = await response.json()
      state.sourcePosts = Array.isArray(data.posts) ? data.posts : []
      state.sessionPosts = shuffle(state.sourcePosts).slice(0, 100)
      renderFeed()
      state.marketplace = staticMarketplaceItems()
      renderMarketplace()
    } catch (error) {
      $('#feedList').innerHTML = `<div class="placeholder card"><h2>BeamBook content could not load</h2><p>${escapeHtml(error.message)}</p></div>`
      $('#connectionStatus').dataset.state = 'offline'
      $('#connectionStatus').textContent = 'Content error'
    }
  }

  function renderContacts() {
    const contacts = shuffle(state.profiles).slice(0, 14)
    $('#contactList').innerHTML = contacts.map(profile => `<button class="contact">${avatar(profile)}<b>${escapeHtml(profile.name)}</b><span class="online-dot"></span></button>`).join('')
  }

  function init() {
    makeProfiles()
    renderContacts()
    bindUi()
    window.addEventListener('message', onHostMessage)
    const savedTheme = localStorage.getItem('beambook_theme') || 'dark'
    setTheme(savedTheme, false)
    $('#memberCount').textContent = `${(210 + seeded(88) * 90).toFixed(1)}K`
    loadContent()
    postToHost('bb-ready', { version: '0.1.0' })
    setTimeout(() => {
      if (!state.careerConnected) updateMarketConnection({ ok: false, error: 'No BeamNG bridge response yet. If viewing this as a static preview, this is expected.' })
    }, 1800)
  }

  init()
})()
